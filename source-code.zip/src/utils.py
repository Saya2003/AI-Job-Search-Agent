from apify import Actor
from langchain_core.messages import ToolMessage

def log_state(state: dict) -> None:
    """Logs the state of the AI Job Search Agent's execution graph.

    This function logs relevant messages and tool interactions to help debug the agent's workflow.

    Args:
        state (dict): The current state of the agent's execution graph.
    """
    if not state.get('messages'):
        Actor.log.warning('No messages found in state.')
        return

    message = state['messages'][-1]

    # Log tool results if multiple tools are called in parallel
    if isinstance(message, ToolMessage):
        for _message in reversed(state['messages']):
            if hasattr(_message, 'tool_calls'):
                break
            Actor.log.debug('-------- Tool Result --------')
            Actor.log.debug('Tool: %s', _message.name)
            Actor.log.debug('Result: %s', _message.content)

    Actor.log.debug('-------- Latest Message --------')
    Actor.log.debug('Message Content: %s', message)

    # Log tool calls
    if hasattr(message, 'tool_calls'):
        for tool_call in message.tool_calls:
            Actor.log.debug('-------- Tool Call --------')
            Actor.log.debug('Tool Name: %s', tool_call['name'])
            Actor.log.debug('Arguments: %s', tool_call['args'])