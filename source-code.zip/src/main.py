import os
import json
import re
import datetime
from dotenv import load_dotenv
from models.schemas import UserPreferences
from workflows.job_search_workflow import JobSearchWorkflow

# Load environment variables
load_dotenv()

def main():
    """Main function to run the job search agent."""
    print("🤖 Job Search Agent")
    print("===================")

    # Check if API keys are loaded
    apify_token = os.getenv("APIFY_API_TOKEN")
    openai_key = os.getenv("OPENAI_API_KEY")

    if not apify_token or not openai_key:
        print("⚠️  Warning: Missing API keys! Please check your .env file.")
        return
    
    # Get user preferences
    preferences = get_user_preferences()
    
    try:
        # Get user preferences
        preferences = get_user_preferences()
        
        # Initialize and run the workflow
        workflow = JobSearchWorkflow(api_key=apify_token)
        print("\nStarting job search. This may take a few minutes...")
        
        results = workflow.run(preferences)
        
        # Display results
        print("\n✅ Job Search Complete!")
        print(f"Found {results['total_jobs_found']} total jobs")
        print(f"Identified {results['relevant_matches']} relevant matches")
        
        if results["recommendations"]:
            print("\n🏆 Top Recommendations:")
            for i, job in enumerate(results['recommendations'][:5]):
                print(f"{i+1}. {job['title']} at {job['company']}")
                print(f"   Match score: {job['match_score']:.2f}")
                print(f"   Location: {job['location']}")
                print(f"   URL: {job['url']}")
                print(f"   Key skills: {', '.join(job['skills_required'][:5])}")
                print()
        
        print("\n🔍 Job Market Insights:")
        print(results['insights'])
        
        # Save results to file
        save_results(results)

    except Exception as e:
        print(f"❌ An unexpected error occurred: {str(e)}")

def get_user_preferences():
    """Get and validate user preferences for job search."""
    print("Please enter your job search preferences:")
    
    # Get job titles (ensure at least one valid title)
    job_titles = get_valid_input("Job titles (comma separated):", allow_multiple=True)
    
    # Get skills (ensure at least one skill is entered)
    skills = get_valid_input("Your skills (comma separated):", allow_multiple=True)
    
    # Get location (allow empty input for worldwide search)
    location = input("Location (leave empty for any location): ").strip()
    
    # Get remote preference
    remote = get_yes_no_input("Include remote jobs? (y/n): ")
    
    # Get experience level with validation
    experience_options = ["entry", "mid", "senior"]
    experience_level = get_choice_input(
        f"Experience level ({'/'.join(experience_options)}): ", experience_options, default="entry"
    )
    
    # Create user preferences object
    return UserPreferences(
        job_titles=job_titles,
        skills=skills,
        location=location,
        remote=remote,
        experience_level=experience_level
    )

def save_results(results):
    """Save job search results to a JSON file."""
    os.makedirs("results", exist_ok=True)
    
    # Generate a timestamp-based filename
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"results/job_search_{timestamp}.json"
    
    with open(filename, "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\n📁 Results saved to {filename}")

def get_valid_input(prompt, allow_multiple=False):
    """Prompt user for valid input and ensure it's not empty."""
    while True:
        user_input = input(prompt).strip()
        if allow_multiple:
            values = [item.strip() for item in user_input.split(",") if item.strip()]
            if values:
                return values
        elif user_input:
            return user_input
        print("⚠️ Input cannot be empty. Please try again.")

def get_yes_no_input(prompt):
    """Prompt user for a yes/no input and return a boolean."""
    while True:
        user_input = input(prompt).strip().lower()
        if user_input in ("y", "yes"):
            return True
        if user_input in ("n", "no"):
            return False
        print("⚠️ Please enter 'y' for yes or 'n' for no.")

def get_choice_input(prompt, choices, default=None):
    """Prompt user for a choice from a list of options."""
    while True:
        user_input = input(prompt).strip().lower()
        if user_input in choices:
            return user_input
        if default and user_input == "":
            return default
        print(f"⚠️ Invalid choice. Please enter one of {', '.join(choices)}.")

if __name__ == "__main__":
    main()